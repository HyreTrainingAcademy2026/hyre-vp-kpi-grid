// Pulls "Section 14-011: SOP: Hyre VP Role Metrics Library" from ClickUp,
// parses the role ranking + Appendix A KPI tables, and writes data/kpis.json.
// Usage:  CLICKUP_API_TOKEN=pk_xxx node scripts/sync.mjs
//         node scripts/sync.mjs --file test/sample.md   (offline parse)
import { readFileSync, writeFileSync, existsSync } from "node:fs";

const WORKSPACE = process.env.CLICKUP_WORKSPACE_ID || "9016308603";
const DOC = process.env.CLICKUP_DOC_ID || "8cpkwvv-1376";
const PAGE = process.env.CLICKUP_PAGE_ID || "8cpkwvv-275476";
const OUT = process.env.OUT_FILE || "data/kpis.json";

// Client-facing naming rules (non-negotiable).
const RENAME = [
  [/hub\s?spot/gi, "CRM"],
  [/hubstaff/gi, "timekeeping"],
  [/discord/gi, "Hyre communication channel"],
  [/rippling/gi, "Hyre HR tool"],
];
const clean = (s = "") =>
  RENAME.reduce((t, [re, rep]) => t.replace(re, rep), s)
    .replace(/\\([.\-_*|])/g, "$1")
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/\*\*/g, "")
    .replace(/\s+/g, " ")
    .trim();

const cells = (line) => {
  const t = line.trim();
  if (!t.startsWith("|")) return null;
  return t.replace(/^\|/, "").replace(/\|$/, "").split(/(?<!\\)\|/).map((c) => c.trim());
};

export function parse(md) {
  const lines = md.split(/\r?\n/);

  // 1) Ranking table: | Rank | Role | Source demand / status | AI integration | Industry / group |
  const ranking = {};
  const hdr = lines.findIndex((l) => /^\|\s*Rank\s*\|\s*Role\s*\|/i.test(l.trim()));
  if (hdr >= 0) {
    for (let i = hdr + 2; i < lines.length; i++) {
      const c = cells(lines[i]);
      if (!c || c.length < 5) break;
      ranking[Number(c[0])] = { demand: clean(c[2]), ai: clean(c[3]), group: clean(c[4]) };
    }
  }

  // 2) Appendix A role blocks
  const roles = [];
  for (let i = 0; i < lines.length; i++) {
    const head = cells(lines[i]);
    const next = lines[i + 1] && lines[i + 1].trim();
    if (!head || head.length !== 1 || !/^\|\s*-{3,}\s*\|$/.test(next || "")) continue;
    const m = head[0].match(/^(\d+)\\?\.\s+(.+)$/);
    if (!m) continue;
    const rank = Number(m[1]);
    const meta = cells(lines[i + 2] || "") || [];
    const kpis = [];
    let j = i + 3;
    const h = cells(lines[j] || "");
    if (h && /metric/i.test(h[0])) j++;
    for (; j < lines.length; j++) {
      const r = cells(lines[j]);
      if (!r || r.length < 4) break;
      kpis.push({ metric: clean(r[0]), weight: clean(r[1]), formula: clean(r[2]), why: clean(r[3]) });
    }
    const rk = ranking[rank] || {};
    const aiFromMeta = (meta.find((x) => /AI INTEGRATION/i.test(x)) || "").split(":")[1];
    roles.push({
      rank,
      name: clean(m[2]),
      category: clean(meta[0] || rk.group || ""),
      status: clean(meta[1] || rk.demand || ""),
      ai: clean(rk.ai || aiFromMeta || "").toLowerCase().replace(/^\w/, (c) => c.toUpperCase()),
      group: rk.group || clean(meta[0] || ""),
      kpis,
    });
    i = j;
  }
  roles.sort((a, b) => a.rank - b.rank);
  return roles;
}

async function fetchPage() {
  const token = process.env.CLICKUP_API_TOKEN;
  if (!token) throw new Error("CLICKUP_API_TOKEN is not set");
  const url = `https://api.clickup.com/api/v3/workspaces/${WORKSPACE}/docs/${DOC}/pages/${PAGE}?content_format=text%2Fmd`;
  const res = await fetch(url, { headers: { Authorization: token, accept: "application/json" } });
  if (!res.ok) throw new Error(`ClickUp API ${res.status}: ${await res.text()}`);
  const j = await res.json();
  return { md: j.content || "", name: j.name, updated: j.date_updated };
}

const fileArg = process.argv.indexOf("--file");
const src = fileArg > 0
  ? { md: readFileSync(process.argv[fileArg + 1], "utf8"), name: "local file", updated: null }
  : await fetchPage();

const roles = parse(src.md);
if (roles.length < 5) {
  console.error(`Parsed only ${roles.length} roles — refusing to overwrite ${OUT}.`);
  process.exit(1);
}
const payload = {
  source: "Hyre VP Role Metrics Library (Section 14-011)",
  sourceUpdated: src.updated ? new Date(Number(src.updated)).toISOString() : null,
  roleCount: roles.length,
  roles,
};
const next = JSON.stringify(payload, null, 2) + "\n";
const prev = existsSync(OUT) ? readFileSync(OUT, "utf8") : "";
if (prev === next) console.log("No changes.");
else { writeFileSync(OUT, next); console.log(`Wrote ${roles.length} roles to ${OUT}`); }
