# Hyre · VP Performance KPI Tracking Grid

Interactive, client-facing KPI grid. Data is pulled automatically from the ClickUp doc
**Section 14-011: SOP: Hyre VP Role Metrics Library** and published with GitHub Pages.

## How auto-update works
- `.github/workflows/sync.yml` runs every 30 minutes (and on manual run / push).
- `scripts/sync.mjs` reads the ClickUp page via the ClickUp API, parses the ranking table and
  Appendix A KPI tables, and writes `data/kpis.json`.
- If anything changed, the bot commits it and redeploys the page.
- Client-facing naming rules are applied automatically (tool names are replaced with neutral terms).

## One-time setup
1. Repo **Settings → Secrets and variables → Actions → New secret**: `CLICKUP_API_TOKEN` = your ClickUp personal token (`pk_...`).
2. Repo **Settings → Pages → Source: GitHub Actions**.
3. **Actions → Sync KPIs from ClickUp & deploy → Run workflow**.

Instant refresh (optional): send a `repository_dispatch` event of type `clickup-doc-updated`.

## Deep links
`https://<owner>.github.io/<repo>/#role=24` opens a specific role (number = rank in the library).
